<div class="navbar">
    <a href="<?= HOST; ?>connexion">S'inscrire ou se connecter</a>
</div>