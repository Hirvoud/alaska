<div class="navbar">
    <?= $_SESSION["user"]["pseudo"]; ?> : <a href="<?= HOST; ?>tableau-de-bord">Tableau de bord</a> − <a href="<?= HOST; ?>deconnexion">Déconnexion</a>
</div>