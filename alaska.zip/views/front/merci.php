<div class="row chap">
    <p>
        <a href="<?= HOST; ?>accueil">Retour à l'accueil</a>
    </p>
    <h3>Merci de votre inscription, <?= htmlspecialchars($param1); ?></h3>
</div>
