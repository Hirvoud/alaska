<div class="row chap">    
    <h2>Erreur 404</h2>
    <h2>Il n'y a rien ici.</h2>
    
    <p><a href="<?= HOST; ?>accueil">Retour à la page d'accueil</a></p>
</div>