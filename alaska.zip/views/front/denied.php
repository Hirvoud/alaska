<div class="row chap">    
    <h2>Vous n'avez pas l'autorisation d'effectuer cette opération.</h2>
    
    <p><a href="<?= HOST; ?>accueil">Retour à la page d'accueil</a></p>
</div>