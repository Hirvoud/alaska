<div class="row chap">
    <h2>Erreur d'identifiant ou de mot de passe.</h2>
    
    <p><a href="<?= HOST; ?>accueil">Retour à la page d'accueil</a></p>
</div>