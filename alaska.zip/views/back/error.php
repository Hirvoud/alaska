<div class="row chap">
    <p><a href="<?= HOST; ?>accueil">Retour à la page d'accueil</a></p>
    <div class="col-lg-5">
        <p>Erreur : <?= $param1 ?></p>
    </div>
</div>